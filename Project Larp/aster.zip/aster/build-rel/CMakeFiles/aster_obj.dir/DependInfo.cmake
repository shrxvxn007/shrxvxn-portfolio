
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/shrxvxn/Downloads/aster/src/core/types.cpp" "CMakeFiles/aster_obj.dir/src/core/types.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/core/types.cpp.o.d"
  "/Users/shrxvxn/Downloads/aster/src/replay/parser.cpp" "CMakeFiles/aster_obj.dir/src/replay/parser.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/replay/parser.cpp.o.d"
  "/Users/shrxvxn/Downloads/aster/src/replay/replay_engine.cpp" "CMakeFiles/aster_obj.dir/src/replay/replay_engine.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/replay/replay_engine.cpp.o.d"
  "/Users/shrxvxn/Downloads/aster/src/strategy/analytics.cpp" "CMakeFiles/aster_obj.dir/src/strategy/analytics.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/strategy/analytics.cpp.o.d"
  "/Users/shrxvxn/Downloads/aster/src/strategy/backtest.cpp" "CMakeFiles/aster_obj.dir/src/strategy/backtest.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/strategy/backtest.cpp.o.d"
  "/Users/shrxvxn/Downloads/aster/src/strategy/mm_strategy.cpp" "CMakeFiles/aster_obj.dir/src/strategy/mm_strategy.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/strategy/mm_strategy.cpp.o.d"
  "/Users/shrxvxn/Downloads/aster/src/strategy/risk_manager.cpp" "CMakeFiles/aster_obj.dir/src/strategy/risk_manager.cpp.o" "gcc" "CMakeFiles/aster_obj.dir/src/strategy/risk_manager.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
