# Empty dependencies file for aster_obj.
# This may be replaced when dependencies are built.
