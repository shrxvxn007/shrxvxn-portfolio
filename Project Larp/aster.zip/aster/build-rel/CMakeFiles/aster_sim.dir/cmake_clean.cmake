file(REMOVE_RECURSE
  "CMakeFiles/aster_sim.dir/src/sim.cpp.o"
  "CMakeFiles/aster_sim.dir/src/sim.cpp.o.d"
  "aster_sim"
  "aster_sim.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/aster_sim.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
