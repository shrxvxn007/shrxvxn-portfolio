file(REMOVE_RECURSE
  "CMakeFiles/aster_obj.dir/src/core/types.cpp.o"
  "CMakeFiles/aster_obj.dir/src/core/types.cpp.o.d"
  "CMakeFiles/aster_obj.dir/src/replay/parser.cpp.o"
  "CMakeFiles/aster_obj.dir/src/replay/parser.cpp.o.d"
  "CMakeFiles/aster_obj.dir/src/replay/replay_engine.cpp.o"
  "CMakeFiles/aster_obj.dir/src/replay/replay_engine.cpp.o.d"
  "CMakeFiles/aster_obj.dir/src/strategy/analytics.cpp.o"
  "CMakeFiles/aster_obj.dir/src/strategy/analytics.cpp.o.d"
  "CMakeFiles/aster_obj.dir/src/strategy/backtest.cpp.o"
  "CMakeFiles/aster_obj.dir/src/strategy/backtest.cpp.o.d"
  "CMakeFiles/aster_obj.dir/src/strategy/mm_strategy.cpp.o"
  "CMakeFiles/aster_obj.dir/src/strategy/mm_strategy.cpp.o.d"
  "CMakeFiles/aster_obj.dir/src/strategy/risk_manager.cpp.o"
  "CMakeFiles/aster_obj.dir/src/strategy/risk_manager.cpp.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/aster_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
