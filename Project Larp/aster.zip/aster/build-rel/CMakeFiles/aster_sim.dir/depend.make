# Empty dependencies file for aster_sim.
# This may be replaced when dependencies are built.
