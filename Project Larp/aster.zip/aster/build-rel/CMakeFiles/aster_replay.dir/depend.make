# Empty dependencies file for aster_replay.
# This may be replaced when dependencies are built.
