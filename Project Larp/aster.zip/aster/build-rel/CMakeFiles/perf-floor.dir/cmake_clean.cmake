file(REMOVE_RECURSE
  "CMakeFiles/perf-floor"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/perf-floor.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
